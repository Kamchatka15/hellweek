# Hell Week cut list

**Line: Pass 1 = Quiet Shore + Wick + Ashwood + Tempter + Gift. Everything else parked.**

## IN (Pass 1)

- Title: Hell Week
- Zone 1 only: The Quiet Shore (**350×350 starting disk**, 175 stud Day-1 fog wall; Ring A 0–50 is the one-minute teach; Wick peels Ring C/D)
- Core verb: pick Ashwood → carry (cap 3) → feed Wick
- Wick: fuel, warm radius, fog peel, PointLight
- Clock: Day 1–3 playable; 4–7 clock can exist but tuning parked
- Tempter: silhouette, Night 1 watch, Night 2+ chase outside light, touch = wake at Wick
- Gift: Day 3, wrong bloom, Weight raises next burn
- HUD: Day, Wick, Carry
- Onboarding: two one-line toasts max
- Shop stubs: Oil, Deep Pockets, Second Wind (optional, after Day 2)
- Look: 99 Nights bar, grey/gold, lighting rig
- Persist: bestDay + tutorialComplete
- Instrumentation: day reached, death reason, gifts taken, fuel in/out

## PARKED

- Zones named Gehenna, Tartarus, Abyss, Lake of Fire, Outer Darkness, Hades
- Scripture, sermons, salvation products, Satan by name
- Classes / diamond lobby shop
- Rescue sleepers, beds, day multiplier
- Weapons, flashlight, combat
- Extra bosses / biomes
- Weekly leaderboard UI (compute score only)
- Squad oil, collections
- 99 Nights assets, deer, kids, audio, UI

## Pass 2 (after Gate A)

- Days 4–7 burn curve
- Score board weekly
- Cosmetics
- One more trial type
- Second zone only if D1 lives
